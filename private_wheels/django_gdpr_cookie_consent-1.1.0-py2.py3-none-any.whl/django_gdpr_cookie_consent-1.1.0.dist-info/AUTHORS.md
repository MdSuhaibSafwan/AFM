# Authors

- Aidas Bendoraitis (@archatas / @DjangoTricks)
